from django.db import models

class BookModel(models.Model):
    titulo = models.CharField(max_length=150)
    autor = models.CharField(max_length=150)
    valoracion = models.IntegerField(help_text="Valor entre 0 y 10000")

    def __str__(self):
        return self.titulo
