from django.db import models

class BoardsModel(models.Model):
    titulo = models.CharField(max_length=200)
    descripcion = models.TextField()
    modificado = models.DateTimeField(auto_now_add=True)

    class Meta:
        permissions = (
            ("es_miembro_1", "Es miembro con prioridad 1"),
        )

    def __str__(self):
        return self.titulo



